<?php
/**
 * @package formalicious
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/formaliciousstep.class.php');
class FormaliciousStep_mysql extends FormaliciousStep {}
?>