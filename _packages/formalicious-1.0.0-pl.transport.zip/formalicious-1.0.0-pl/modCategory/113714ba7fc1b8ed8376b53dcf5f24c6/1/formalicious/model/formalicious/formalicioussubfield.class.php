<?php

require_once(dirname(__FILE__)).'/formaliciousfield.class.php';

/**
 * @package formalicious
 */
class FormaliciousSubField extends FormaliciousField {}
?>