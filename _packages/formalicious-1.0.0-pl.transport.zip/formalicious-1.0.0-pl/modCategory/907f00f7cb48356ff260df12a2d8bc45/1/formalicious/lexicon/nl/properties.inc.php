<?php
/**
 * Dutch Lexicon Entries for Formalicious
 *
 * @package formalicious
 * @subpackage lexicon
 */
$_lang['prop_formalicious.limit_desc'] = 'Aantal items per pagina.';
$_lang['prop_formalicious.outputseparator_desc'] = 'Een tekenreeks op elke regel te scheiden.';
$_lang['prop_formalicious.sortby_desc'] = 'Veld om op te sorteren.';
$_lang['prop_formalicious.sortdir_desc'] = 'De sorteer volgorde.';
$_lang['prop_formalicious.tpl_desc'] = 'The chunk voor elke regel van items.';
$_lang['prop_formalicious.toplaceholder_desc'] = 'Als dit veld gevuld is komt de content in een placeholder in plaats van direct in de content.';
