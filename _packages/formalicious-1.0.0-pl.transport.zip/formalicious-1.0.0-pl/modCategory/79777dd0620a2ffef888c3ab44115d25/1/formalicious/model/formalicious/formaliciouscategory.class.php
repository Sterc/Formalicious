<?php
/**
 * @package formalicious
 */
class FormaliciousCategory extends xPDOSimpleObject {}
?>