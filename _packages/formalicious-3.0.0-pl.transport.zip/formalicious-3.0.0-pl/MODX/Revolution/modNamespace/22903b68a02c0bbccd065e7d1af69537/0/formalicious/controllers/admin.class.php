<?php

use Sterc\Formalicious\Controllers\Admin;

class FormaliciousAdminManagerController extends Admin
{
}
