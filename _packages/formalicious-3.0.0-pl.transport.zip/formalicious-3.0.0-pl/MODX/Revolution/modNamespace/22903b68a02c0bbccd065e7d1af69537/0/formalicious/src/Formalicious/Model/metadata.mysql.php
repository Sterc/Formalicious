<?php
$xpdo_meta_map = array (
    'xPDO\\Om\\xPDOSimpleObject' =>
    array (
        0 => 'Sterc\\Formalicious\\Model\\FormaliciousCategory',
        1 => 'Sterc\\Formalicious\\Model\\FormaliciousForm',
        2 => 'Sterc\\Formalicious\\Model\\FormaliciousStep',
        3 => 'Sterc\\Formalicious\\Model\\FormaliciousFieldType',
        4 => 'Sterc\\Formalicious\\Model\\FormaliciousField',
        5 => 'Sterc\\Formalicious\\Model\\FormaliciousAnswer',
    ),
);