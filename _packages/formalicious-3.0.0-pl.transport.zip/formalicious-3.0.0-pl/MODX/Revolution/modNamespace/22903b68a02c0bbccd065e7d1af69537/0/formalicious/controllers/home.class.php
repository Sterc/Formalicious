<?php

use Sterc\Formalicious\Controllers\Home;

class FormaliciousHomeManagerController extends Home
{

}
