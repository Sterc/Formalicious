<?php
use Sterc\Formalicious\Controllers\Update;

class FormaliciousUpdateManagerController extends Update
{
}
