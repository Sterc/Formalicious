<?php
use Sterc\Formalicious\Snippets\RenderForm;

$form = new RenderForm($modx);

return $form->run($scriptProperties);