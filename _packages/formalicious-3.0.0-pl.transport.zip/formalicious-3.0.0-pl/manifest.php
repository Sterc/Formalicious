<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MODX Formalicious
![Formalicious version](https://img.shields.io/badge/version-3.0.0-green.svg) ![MODX Extra by Sterc](https://img.shields.io/badge/checked%20by-Gauke%20and%20Roel-blue.svg) ![MODX version requirements](https://img.shields.io/badge/modx%20version%20requirement-2.4%2B-brightgreen.svg)

Formalicious is a tool for MODX content managers, which enables them to manage complex forms using a GUI, without any programming knowledge. The tool makes use of FormIt to render the forms, therefore the properties available in FormIt are used in Formalicious. For example hooks and preHooks are optional settings in Formalicious.

### Requirements ###
* MODX 2.4.0 or greater
* FormIt 4.2.2 or greater

## Snippets

**Voorbeeld snippet call:**

```
{\'!FormaliciousRenderForm\' | snippet : [
	\'form\' 	        => 3,
    \'tplForm\'		=> \'@FILE elements/chunks/formfenom.chunk.tpl\'
]}
```

### How do I get set up? ###

* Install FormIt 2.2.2 or greater with MODX installer
* Install the Formalicious package with MODX installer

To create a form:

* Go to Extras > Formalicious
* Head to the Admin panel and create a category
* Click the tab Types to add field types which can be used in the forms
* When creating a type you can provide a name, template, the possibility to add values to the field and give these values a template, FormIt validators (https://docs.modx.com/extras/revo/formit/formit.validators) and you can add an icon which is shown when choosing a field type in the manager.
* Close the categories and go to the Formalicious overview
* The tabs represent the categories and you can now create forms under these categories
* Click \'Create form\' and add at least a title in the form settings
* You have to save the form settings before you can add any fields to it
* When adding fields, you can also create steps in your form to create sections in which a user can navigate with \'next\' and \'previous\' buttons.
* Click \'Add field\' and choose a field type
* The options of the fields you add, are managed in the Admin panel > Types
* Under the Advanced tab you can add prehooks, posthooks and custom parameters just like FormIt (https://docs.modx.com/extras/revo/formit)

To show the form on a page:

* When installing the Formalicious package, a TV named \'formalicious\' will be created. This TV can be assigned to a template and in the code add this for example to show the form chosen in the TV:
```html
[[!renderForm? &form=`[[!*formalicious]]`]]
```

### Options ###
System settings:

* formalicious.source: the media source id Formalicious will use
',
    'license' => 'Formalicious is proprietary software, developed by Sterc and distributed through modmore.com. By purchasing Formalicious via https://www.modmore.com/formalicious/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope Formalicious is useful to you and we will try to help you successfully use Formalicious, modmore or Sterc is not liable for loss of revenue, data, damages or other financial loss resulting from the installation or use of Formalicious.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor Formalicious for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'changelog' => 'Version 3.0.0-pl
- MODX3 Refactor

Version 2.0.5-pl
- Add hidden input field to heading
- Return FormItParameters as array for Fenom usage
- Set properties so they use the hook config
- Update renderForm class so it reuses the settings set from the snippet properties
- Add step count placeholder to step tpl
- Use {assets_url} for default value of system settings
- Remove the requirement for published_from and published_till

Version 2.0.4-pl
- Fixed undefined bug when clicking View in FormIt in overview grid

Version 2.0.3-pl
- Set required integers by default

Version 2.0.2-pl
- Set currentUrl with step=1 when steps are there
- Make the id column on fields visible

Version 2.0.1-pl
--------------------------
- Add sterc extra settings when not existing

Version 2.0.0-pl
--------------------------
- Add form DB fields published_from and published_till to auto (de)publication forms
- Add field answer DB field selected to set default selected
- Rich text support for field description and form email content.
- Steps (navigation) above the form
- New parameter stepRedirect to redirect a step to a non resource ID (if stepRedirect is set to \'request\' the step will be redirected to the current REQUEST URL)
- New permissions added
    - formalicious_admin to show/hide admin panel
    - formalicious_tab_fields to show/hide fields tab
    - formalicious_tab_advanced to show/hide advanced tab (formalicious_advanced renamed to formalicious_tab_advanced)
- ExtJS refactored for faster and better UI/UX
    - Step preview fixed
    - Toggleable description, placeholder, required and heading fields for each fieldtype
- RenderForm replaced with FormaliciousRenderForm
- All snippets and chunks are prefixed with Formalicious

Version 1.4.1-pl
--------------------------
- Create database fields on update

Version 1.4.0-pl
--------------------------
- Add field description
- Hide advanced tab based on permissions
- Add heading & description fields
- Add field description
- Change fiarcontent from varchar to text for bigger mails

Version 1.3.1-pl
--------------------------
- Add system setting for disable form saving on install
- Change fiarcontent from varchar to text

Version 1.3.0-pl
--------------------------
- Fixed phptype of some fields in schema of tables (PHP 7 compatibility)
- Added system setting to disable overall form saving functionality
- Added russian lexicon

Version 1.2.1-pl (October 2017)
--------------------------
- Remove the limit from the ContentBlocks input field
- Hide autoreply options when autoreply checkbox is unchecked

Version 1.2.0-pl (August 2nd, 2017)
--------------------------
- Removing default limit from fiaremailto field (#31)
- Add back button to form update view
- Add duplicate option to forms grid (#32)
- Update grid action buttons to use modx font-awesome icons
- Make add step/field buttons more visible
- Add preview option to form fields tab
- Add saveTmpFiles FormIt property to default formTpl
- Add formName FormIt property to default formTpl
- Prefix fiar-attachment field with modx base_path
- Only add email hook when emailto is not empty
- Remove default limit of 20 from field-values grid
- Check for common \'spam,email,redirect\' hooks added by Formalicious when saving posthooks
- Add ID field to form-fields grid
- Make sure prehooks are run before the renderForm snippet

Version 1.1.0-pl (April 19th, 2017)
--------------------------
- Fix setting placeholder for stepParam parameter for renderForm
- Show message when trying to display unpublished form (#6)
- Update radio and checkbox chunks to use correct Bootstrap classes (#28)
- Allow emailTpl and fiarTpl to be overwritten with renderForm snippet parameters (#23)
- Add validate and customValidators parameters to renderForm and formTpl (#23)

Version 1.0.1-pl (February 3rd, 2017)
--------------------------
- Added ContentBlocks support (thanks Mark!)
- Fixed installation issues with MODX installations with custom table-prefixes

Version 1.0.0-pl (February 1st, 2017)
--------------------------
- XS-4 New documentation
- XS-11 Changed height of several dialog windows
- XS-12 Spacing adjustments
- XS-19 Gave the default emails a lighter grey
- XS-20 Modified all en/nl lexicons
- XS-21 Fixed inline editing (removed it)

Version 1.0.0-RC2 (January 27th, 2017)
--------------------------
- [#28] Fixed oldstyle actions
- [#29] Improved this very changelog
- [#40] Create a readme
- [#41] New logo for the modmore site!
- [#XS-42] Autoheight for new-field dialog

Version 1.0.0-RC1 (January 26th, 2017)
--------------------------
- [#34] Improved handling of empty fields
- [#37] Radio button # Select # Checkbox options are now required
- [#38] Allowed files are now mentioned
- [#36] Improved default emails
- [#32] Unused description field is now removed
- [#31] Improved placeholder field usage
- [#30] Mention context-NAME in the "Redirect to" field when creating a new form
- [#27] Fixed file upload in multistep form
- [#22] Improved emailTpl
- [#20 + #23 + #35] Improved styling of buttons
- [#17] Fixed category_id fallback
- [#9 + #12] Fixed empty fields in multistep form
- [#13] Fixed email validation
- [#10] Fixed adding parameters not working properly
- [#7] Now shipped with TV
- [#8] Fixed uninstallation proces
- [#4] "Update type" dialog is now bigger
- [#2] Fixed select form-email-field when creating a form
- [#1] Fixed empty field when creating a form
- [#6] Improved adding fields
- [#5] Improved step-creation flow
- [#3] Replaced form-description with "Email header text"

Version 0.6.0 (2016)
--------------------------
- Create form categories
- Ability to create form steps
- Ability to save forms in FormIt (FormIt V2.2.2#) CMP
- Added ability to setup autoresponder in form
- Updated lexicons
',
    'requires' => 
    array (
      'FormIt' => '>=5.0.0',
    ),
    'setup-options' => 'formalicious-3.0.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1cdc5a90a4bff0924b43f497b78ec4df',
      'native_key' => 'formalicious',
      'filename' => 'MODX/Revolution/modNamespace/22903b68a02c0bbccd065e7d1af69537.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cbb1b448828f4b68319b62c4c8006b4c',
      'native_key' => 'formalicious.branding_url',
      'filename' => 'MODX/Revolution/modSystemSetting/a9b15620ae55bebe99a1df4d57dc5669.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ab9ff77f7e21b89d8efabe975414e34a',
      'native_key' => 'formalicious.branding_url_help',
      'filename' => 'MODX/Revolution/modSystemSetting/56f016bbdc8fef73f3ec501a31744749.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bb5bd610a87c3a745a5075ac7432569e',
      'native_key' => 'formalicious.saveforms',
      'filename' => 'MODX/Revolution/modSystemSetting/0f0a75053518ae51aed1a20dbd2f4ff5.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '595b116751d7300071b7d4a21672edf5',
      'native_key' => 'formalicious.saveforms_prefix',
      'filename' => 'MODX/Revolution/modSystemSetting/13553caaf85714a3c94b7bc861691be3.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a1bf434f85e446b57fe9ed016492beba',
      'native_key' => 'formalicious.disallowed_hooks',
      'filename' => 'MODX/Revolution/modSystemSetting/bf0e208d3e48b32d2c94bef406b876b4.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e99be8291e2c04f7b85394b66038bd5f',
      'native_key' => 'formalicious.preview_css',
      'filename' => 'MODX/Revolution/modSystemSetting/7b06cfee688bb8fee0c61fe7e047ad57.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74172e436f350d140951b2b16a00e150',
      'native_key' => 'formalicious.source',
      'filename' => 'MODX/Revolution/modSystemSetting/ac68f498ac4cec7e45dfce4b4f60f80b.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f226486c78ce3391665a0eb9b4b8fff0',
      'native_key' => 'formalicious.use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/d4829ab949224017876589fe12b7a0fa.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '700a30e54ee066075395cb5ad8d41359',
      'native_key' => 'formalicious.editor_menubar',
      'filename' => 'MODX/Revolution/modSystemSetting/a649df0f8bb3afdb38482807f994040f.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7522b60ec1dc87e6f4f7684ee7405b9d',
      'native_key' => 'formalicious.editor_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/e6821de183ae95dd1f2423c8cb965b9a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7cce18362e37490d07193d2b65e6f680',
      'native_key' => 'formalicious.editor_statusbar',
      'filename' => 'MODX/Revolution/modSystemSetting/1438a74b7cabe4c702470abb863c682d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '06d90c0bc4f986bf6d0413bc36fa40fc',
      'native_key' => 'formalicious.editor_toolbar1',
      'filename' => 'MODX/Revolution/modSystemSetting/5bb04aecdafbe53cc5931632ea02c352.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60c92f3a8bd040d52bec0f75320ea77b',
      'native_key' => 'formalicious.editor_toolbar2',
      'filename' => 'MODX/Revolution/modSystemSetting/ce4eed44caab1baf279c8029138e3100.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9aa8e6080d828a6ecaf20d037719999f',
      'native_key' => 'formalicious.editor_toolbar3',
      'filename' => 'MODX/Revolution/modSystemSetting/3a10d9a6a4367d586a2cbf13e87aa34e.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'e5f7728b6a75242410e27566acd321cc',
      'native_key' => 'formalicious',
      'filename' => 'MODX/Revolution/modMenu/fe5ca56199d8bcfffb24f9cd99b249b7.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3e65d14f50e3682f963513c5c7e0150e',
      'native_key' => '3e65d14f50e3682f963513c5c7e0150e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d5819ed418091fc72a66bf4a84657555.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'b785a67ae4e1511e88840b7c870715ef',
      'native_key' => 'b785a67ae4e1511e88840b7c870715ef',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d57838e88764c502db0ca656f58e51c9.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'bee215439373d9073bce1152779606fd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/8b2fe9da8a32f0496e18be92e121006a.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '184f93011e39f3d1eac33569fd244690',
      'native_key' => '184f93011e39f3d1eac33569fd244690',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/3676987da683afb3060d32c2e1b601f2.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'c1ef451e4d2ec1c9d7cddfd59312fd5d',
      'native_key' => 'c1ef451e4d2ec1c9d7cddfd59312fd5d',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/57337eb03da28f0fdbad3f57663a412b.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '35e4cec7b975694a08257c5e0debd4ea',
      'native_key' => '35e4cec7b975694a08257c5e0debd4ea',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d4dda727ace505d3a24ccfdf44159964.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'ccffa4b855707a51be4cb51f12a66be5',
      'native_key' => 'ccffa4b855707a51be4cb51f12a66be5',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/aa009fc409dc361abb564a5bb6d0fab3.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '1f1037432cd658aeb86e97301e44f7c4',
      'native_key' => '1f1037432cd658aeb86e97301e44f7c4',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/49830b45e1bce898f97200ec7d843727.vehicle',
    ),
  ),
);