<?php
/**
 * @package formalicious
 */
$xpdo_meta_map['FormaliciousSubField']= array (
  'package' => 'formalicious',
  'version' => NULL,
  'table' => 'formalicious_subfields',
  'extends' => 'FormaliciousField',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
