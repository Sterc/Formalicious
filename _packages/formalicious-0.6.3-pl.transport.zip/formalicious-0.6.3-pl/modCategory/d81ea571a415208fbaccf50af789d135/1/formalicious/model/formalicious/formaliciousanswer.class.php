<?php
/**
 * @package formalicious
 */
class FormaliciousAnswer extends xPDOSimpleObject {}
?>