<?php
/**
 * @package formalicious
 */
class FormaliciousField extends xPDOSimpleObject {}
?>