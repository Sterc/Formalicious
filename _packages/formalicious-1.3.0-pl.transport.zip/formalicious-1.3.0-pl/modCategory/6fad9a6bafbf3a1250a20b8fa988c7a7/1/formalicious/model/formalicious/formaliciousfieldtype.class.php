<?php
/**
 * @package formalicious
 */
class FormaliciousFieldType extends xPDOSimpleObject {}
?>