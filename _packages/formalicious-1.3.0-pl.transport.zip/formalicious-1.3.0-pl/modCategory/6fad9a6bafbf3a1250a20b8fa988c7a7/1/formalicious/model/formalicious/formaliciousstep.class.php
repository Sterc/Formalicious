<?php
/**
 * @package formalicious
 */
class FormaliciousStep extends xPDOSimpleObject {}
?>