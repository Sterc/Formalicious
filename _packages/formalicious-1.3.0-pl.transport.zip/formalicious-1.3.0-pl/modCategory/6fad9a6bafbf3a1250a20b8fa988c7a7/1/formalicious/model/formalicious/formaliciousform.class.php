<?php
/**
 * @package formalicious
 */
class FormaliciousForm extends xPDOSimpleObject {}
?>