<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Formalicious is proprietary software, developed by Sterc and distributed through modmore.com. By purchasing Formalicious via https://www.modmore.com/formalicious/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope Formalicious is useful to you and we will try to help you successfully use Formalicious, modmore or Sterc is not liable for loss of revenue, data, damages or other financial loss resulting from the installation or use of Formalicious.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor Formalicious for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'changelog' => 'Version 3.1.1-pl
- Renamed usage of rank column to avoid conflict with reserved keywords in MySQL 8. This prevents SQL errors during table creation or queries in newer MySQL versions

Version 3.1.0-pl
- Move to datetime object to prevent forms from breaking when publishing beyond 2038
- Add form action field to which the form will be posted instead of the landingspage (requires latest FormIt.)

Version 3.0.0-pl
- MODX3 Refactor

Version 2.0.5-pl
- Add hidden input field to heading
- Return FormItParameters as array for Fenom usage
- Set properties so they use the hook config
- Update renderForm class so it reuses the settings set from the snippet properties
- Add step count placeholder to step tpl
- Use {assets_url} for default value of system settings
- Remove the requirement for published_from and published_till

Version 2.0.4-pl
- Fixed undefined bug when clicking View in FormIt in overview grid

Version 2.0.3-pl
- Set required integers by default

Version 2.0.2-pl
- Set currentUrl with step=1 when steps are there
- Make the id column on fields visible

Version 2.0.1-pl
--------------------------
- Add sterc extra settings when not existing

Version 2.0.0-pl
--------------------------
- Add form DB fields published_from and published_till to auto (de)publication forms
- Add field answer DB field selected to set default selected
- Rich text support for field description and form email content.
- Steps (navigation) above the form
- New parameter stepRedirect to redirect a step to a non resource ID (if stepRedirect is set to \'request\' the step will be redirected to the current REQUEST URL)
- New permissions added
    - formalicious_admin to show/hide admin panel
    - formalicious_tab_fields to show/hide fields tab
    - formalicious_tab_advanced to show/hide advanced tab (formalicious_advanced renamed to formalicious_tab_advanced)
- ExtJS refactored for faster and better UI/UX
    - Step preview fixed
    - Toggleable description, placeholder, required and heading fields for each fieldtype
- RenderForm replaced with FormaliciousRenderForm
- All snippets and chunks are prefixed with Formalicious

Version 1.4.1-pl
--------------------------
- Create database fields on update

Version 1.4.0-pl
--------------------------
- Add field description
- Hide advanced tab based on permissions
- Add heading & description fields
- Add field description
- Change fiarcontent from varchar to text for bigger mails

Version 1.3.1-pl
--------------------------
- Add system setting for disable form saving on install
- Change fiarcontent from varchar to text

Version 1.3.0-pl
--------------------------
- Fixed phptype of some fields in schema of tables (PHP 7 compatibility)
- Added system setting to disable overall form saving functionality
- Added russian lexicon

Version 1.2.1-pl (October 2017)
--------------------------
- Remove the limit from the ContentBlocks input field
- Hide autoreply options when autoreply checkbox is unchecked

Version 1.2.0-pl (August 2nd, 2017)
--------------------------
- Removing default limit from fiaremailto field (#31)
- Add back button to form update view
- Add duplicate option to forms grid (#32)
- Update grid action buttons to use modx font-awesome icons
- Make add step/field buttons more visible
- Add preview option to form fields tab
- Add saveTmpFiles FormIt property to default formTpl
- Add formName FormIt property to default formTpl
- Prefix fiar-attachment field with modx base_path
- Only add email hook when emailto is not empty
- Remove default limit of 20 from field-values grid
- Check for common \'spam,email,redirect\' hooks added by Formalicious when saving posthooks
- Add ID field to form-fields grid
- Make sure prehooks are run before the renderForm snippet

Version 1.1.0-pl (April 19th, 2017)
--------------------------
- Fix setting placeholder for stepParam parameter for renderForm
- Show message when trying to display unpublished form (#6)
- Update radio and checkbox chunks to use correct Bootstrap classes (#28)
- Allow emailTpl and fiarTpl to be overwritten with renderForm snippet parameters (#23)
- Add validate and customValidators parameters to renderForm and formTpl (#23)

Version 1.0.1-pl (February 3rd, 2017)
--------------------------
- Added ContentBlocks support (thanks Mark!)
- Fixed installation issues with MODX installations with custom table-prefixes

Version 1.0.0-pl (February 1st, 2017)
--------------------------
- XS-4 New documentation
- XS-11 Changed height of several dialog windows
- XS-12 Spacing adjustments
- XS-19 Gave the default emails a lighter grey
- XS-20 Modified all en/nl lexicons
- XS-21 Fixed inline editing (removed it)

Version 1.0.0-RC2 (January 27th, 2017)
--------------------------
- [#28] Fixed oldstyle actions
- [#29] Improved this very changelog
- [#40] Create a readme
- [#41] New logo for the modmore site!
- [#XS-42] Autoheight for new-field dialog

Version 1.0.0-RC1 (January 26th, 2017)
--------------------------
- [#34] Improved handling of empty fields
- [#37] Radio button # Select # Checkbox options are now required
- [#38] Allowed files are now mentioned
- [#36] Improved default emails
- [#32] Unused description field is now removed
- [#31] Improved placeholder field usage
- [#30] Mention context-NAME in the "Redirect to" field when creating a new form
- [#27] Fixed file upload in multistep form
- [#22] Improved emailTpl
- [#20 + #23 + #35] Improved styling of buttons
- [#17] Fixed category_id fallback
- [#9 + #12] Fixed empty fields in multistep form
- [#13] Fixed email validation
- [#10] Fixed adding parameters not working properly
- [#7] Now shipped with TV
- [#8] Fixed uninstallation proces
- [#4] "Update type" dialog is now bigger
- [#2] Fixed select form-email-field when creating a form
- [#1] Fixed empty field when creating a form
- [#6] Improved adding fields
- [#5] Improved step-creation flow
- [#3] Replaced form-description with "Email header text"

Version 0.6.0 (2016)
--------------------------
- Create form categories
- Ability to create form steps
- Ability to save forms in FormIt (FormIt V2.2.2#) CMP
- Added ability to setup autoresponder in form
- Updated lexicons
',
    'requires' => 
    array (
      'FormIt' => '>=5.0.0',
    ),
    'setup-options' => 'formalicious-3.1.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '4acec4e7cdb2787dbb4bf9cbc981863f',
      'native_key' => 'formalicious',
      'filename' => 'MODX/Revolution/modNamespace/66b378bd494a008f7b2e5a838bda8428.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c49446c13759e3213315055f455d7df2',
      'native_key' => 'formalicious.branding_url',
      'filename' => 'MODX/Revolution/modSystemSetting/399c79f596f6edf5a4f1bbfcf5b2d3b0.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38084bfce43bb6d36a2b034887b01713',
      'native_key' => 'formalicious.branding_url_help',
      'filename' => 'MODX/Revolution/modSystemSetting/df438186531fcefef123b6f76dc8bafe.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd31489f6756ab62dfb80e732a54bcfa6',
      'native_key' => 'formalicious.saveforms',
      'filename' => 'MODX/Revolution/modSystemSetting/952a415e2dd3401106624de4d63a2cd6.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f9ca2160e9459ac2db7f385d806ad900',
      'native_key' => 'formalicious.saveforms_prefix',
      'filename' => 'MODX/Revolution/modSystemSetting/4126d582ae718bda8db6e97bf25fa7f8.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b7d6957efaf8ddb7357c3bf251d9aa1',
      'native_key' => 'formalicious.disallowed_hooks',
      'filename' => 'MODX/Revolution/modSystemSetting/17c695b75dfe1b909d2df5ec71a5f8fc.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2d69046a1978b8cd834ee8535b6165b2',
      'native_key' => 'formalicious.preview_css',
      'filename' => 'MODX/Revolution/modSystemSetting/0d494a484252c1c51437e8a6f4121e44.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b000e8f6c219e6196555007755a51c75',
      'native_key' => 'formalicious.source',
      'filename' => 'MODX/Revolution/modSystemSetting/c04039f2ba6cc858b5c0e6361dc7b1e3.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0bc52625207bbac76d89fb6a019203cc',
      'native_key' => 'formalicious.use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/4ac86c82f01476cf78136134c4379cb7.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4cac61fb42dc72f21f0ad096656794b9',
      'native_key' => 'formalicious.editor_menubar',
      'filename' => 'MODX/Revolution/modSystemSetting/291ad600cc50f03e2c35c5e874521335.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d1d30c66810631f72992069bc1143ce',
      'native_key' => 'formalicious.editor_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/8cab2c50754320ce1cdb97121277d91a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '385d701f1a262cadae6497b9d9667ea8',
      'native_key' => 'formalicious.editor_statusbar',
      'filename' => 'MODX/Revolution/modSystemSetting/85e0d1cd08c32143e9c6935025b2e05d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '67c094ccfc4497dfbebb7f042fdec730',
      'native_key' => 'formalicious.editor_toolbar1',
      'filename' => 'MODX/Revolution/modSystemSetting/08f66b34d34c86aa9406f3a97a96e32d.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2536a387f38a69c3473625f4fbf92ceb',
      'native_key' => 'formalicious.editor_toolbar2',
      'filename' => 'MODX/Revolution/modSystemSetting/09204f93134c4828b48a1825aad937f3.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e5fe41049e7781d447362fc69d4214e',
      'native_key' => 'formalicious.editor_toolbar3',
      'filename' => 'MODX/Revolution/modSystemSetting/7296793a445791cd4cb99aada657f4ec.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '7ec0fa14da7399b6cde691c4acd00b29',
      'native_key' => '7ec0fa14da7399b6cde691c4acd00b29',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/aa8ac467f63091e4bbebdbabf7ec013a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '70ccb497767a59f865b76f0abd6e7777',
      'native_key' => 'formalicious',
      'filename' => 'MODX/Revolution/modMenu/28925d172ac3f6f709c5137737599691.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '8139307011a1a8072213fb5d9f967552',
      'native_key' => '8139307011a1a8072213fb5d9f967552',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/00bc7d65e04e1450c7570954f251a047.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '8b15b8b4d6b03148e26911e01a45fcd7',
      'native_key' => '8b15b8b4d6b03148e26911e01a45fcd7',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/c1367967263b0910a2d462c7a3f6c198.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'e34fda6765beb0c6333b9fee6d309f29',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/24c598dd0d4b3de50cc5dc6997355ba3.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '43f7b7899c0ec72bd6fd0dedf7b5b68d',
      'native_key' => '43f7b7899c0ec72bd6fd0dedf7b5b68d',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d806c254a03b7b013092c2c3c4a9d7a5.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'eb86005031f6f638dde95b686568cb8e',
      'native_key' => 'eb86005031f6f638dde95b686568cb8e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/bb26bc6108253ab7fc4bd6f8e88a22bd.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'b9df8a7fcb1bcfe60efaa13c0d8633c5',
      'native_key' => 'b9df8a7fcb1bcfe60efaa13c0d8633c5',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/57746e2e3f8feac4ceb844669aacbfaf.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '5cb0b8a8d1f315ef7c0e8a9f5dc37bf5',
      'native_key' => '5cb0b8a8d1f315ef7c0e8a9f5dc37bf5',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/9c15f890d5476e188c2e4c5ee50bfba6.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '293cc6e7e1035efa98380542d5d1909f',
      'native_key' => '293cc6e7e1035efa98380542d5d1909f',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/1e1a9389acfa18e4ca98d188dbf12c01.vehicle',
    ),
  ),
);