<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Formalicious is proprietary software, developed by Sterc and distributed through modmore.com. By purchasing Formalicious via https://www.modmore.com/formalicious/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope Formalicious is useful to you and we will try to help you successfully use Formalicious, modmore or Sterc is not liable for loss of revenue, data, damages or other financial loss resulting from the installation or use of Formalicious.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor Formalicious for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'readme' => '--------------------
Formalicious
--------------------
Author: Sterc <modx@sterc.nl>
--------------------

Formalicious is the most powerful and easiest MODX form builder, with built-in multi-step forms, 8 field types, validation and the ability to use hooks and other advanced FormIt features.

Important! Since Formalicious 2.0.0 we refactored some snippets and chunks. The snippet RenderForm is replaced with FormaliciousRenderForm.
Please check your snippet and the script properties and check if the chunks/templates of the \'Fieldtypes\' are correct..
',
    'changelog' => 'Version 2.0.4-pl
- Fixed undefined bug when clicking View in FormIt in overview grid

Version 2.0.3-pl
- Set required integers by default

Version 2.0.2-pl
- Set currentUrl with step=1 when steps are there
- Make the id column on fields visible

Version 2.0.1-pl
--------------------------
- Add sterc extra settings when not existing

Version 2.0.0-pl
--------------------------
- Add form DB fields published_from and published_till to auto (de)publication forms
- Add field answer DB field selected to set default selected
- Rich text support for field description and form email content.
- Steps (navigation) above the form
- New parameter stepRedirect to redirect a step to a non resource ID (if stepRedirect is set to \'request\' the step will be redirected to the current REQUEST URL)
- New permissions added
    - formalicious_admin to show/hide admin panel
    - formalicious_tab_fields to show/hide fields tab
    - formalicious_tab_advanced to show/hide advanced tab (formalicious_advanced renamed to formalicious_tab_advanced)
- ExtJS refactored for faster and better UI/UX
    - Step preview fixed
    - Toggleable description, placeholder, required and heading fields for each fieldtype
- RenderForm replaced with FormaliciousRenderForm
- All snippets and chunks are prefixed with Formalicious

Version 1.4.1-pl
--------------------------
- Create database fields on update

Version 1.4.0-pl
--------------------------
- Add field description
- Hide advanced tab based on permissions
- Add heading & description fields
- Add field description
- Change fiarcontent from varchar to text for bigger mails

Version 1.3.1-pl
--------------------------
- Add system setting for disable form saving on install
- Change fiarcontent from varchar to text

Version 1.3.0-pl
--------------------------
- Fixed phptype of some fields in schema of tables (PHP 7 compatibility)
- Added system setting to disable overall form saving functionality
- Added russian lexicon

Version 1.2.1-pl (October 2017)
--------------------------
- Remove the limit from the ContentBlocks input field
- Hide autoreply options when autoreply checkbox is unchecked

Version 1.2.0-pl (August 2nd, 2017)
--------------------------
- Removing default limit from fiaremailto field (#31)
- Add back button to form update view
- Add duplicate option to forms grid (#32)
- Update grid action buttons to use modx font-awesome icons
- Make add step/field buttons more visible
- Add preview option to form fields tab
- Add saveTmpFiles FormIt property to default formTpl
- Add formName FormIt property to default formTpl
- Prefix fiar-attachment field with modx base_path
- Only add email hook when emailto is not empty
- Remove default limit of 20 from field-values grid
- Check for common \'spam,email,redirect\' hooks added by Formalicious when saving posthooks
- Add ID field to form-fields grid
- Make sure prehooks are run before the renderForm snippet

Version 1.1.0-pl (April 19th, 2017)
--------------------------
- Fix setting placeholder for stepParam parameter for renderForm
- Show message when trying to display unpublished form (#6)
- Update radio and checkbox chunks to use correct Bootstrap classes (#28)
- Allow emailTpl and fiarTpl to be overwritten with renderForm snippet parameters (#23)
- Add validate and customValidators parameters to renderForm and formTpl (#23)

Version 1.0.1-pl (February 3rd, 2017)
--------------------------
- Added ContentBlocks support (thanks Mark!)
- Fixed installation issues with MODX installations with custom table-prefixes

Version 1.0.0-pl (February 1st, 2017)
--------------------------
- XS-4 New documentation
- XS-11 Changed height of several dialog windows
- XS-12 Spacing adjustments
- XS-19 Gave the default emails a lighter grey
- XS-20 Modified all en/nl lexicons
- XS-21 Fixed inline editing (removed it)

Version 1.0.0-RC2 (January 27th, 2017)
--------------------------
- [#28] Fixed oldstyle actions
- [#29] Improved this very changelog
- [#40] Create a readme
- [#41] New logo for the modmore site!
- [#XS-42] Autoheight for new-field dialog

Version 1.0.0-RC1 (January 26th, 2017)
--------------------------
- [#34] Improved handling of empty fields
- [#37] Radio button # Select # Checkbox options are now required
- [#38] Allowed files are now mentioned
- [#36] Improved default emails
- [#32] Unused description field is now removed
- [#31] Improved placeholder field usage
- [#30] Mention context-NAME in the "Redirect to" field when creating a new form
- [#27] Fixed file upload in multistep form
- [#22] Improved emailTpl
- [#20 + #23 + #35] Improved styling of buttons
- [#17] Fixed category_id fallback
- [#9 + #12] Fixed empty fields in multistep form
- [#13] Fixed email validation
- [#10] Fixed adding parameters not working properly
- [#7] Now shipped with TV
- [#8] Fixed uninstallation proces
- [#4] "Update type" dialog is now bigger
- [#2] Fixed select form-email-field when creating a form
- [#1] Fixed empty field when creating a form
- [#6] Improved adding fields
- [#5] Improved step-creation flow
- [#3] Replaced form-description with "Email header text"

Version 0.6.0 (2016)
--------------------------
- Create form categories
- Ability to create form steps
- Ability to save forms in FormIt (FormIt V2.2.2#) CMP
- Added ability to setup autoresponder in form
- Updated lexicons
',
    'setup-options' => 'formalicious-2.0.4-pl/setup-options.php',
    'requires' => 
    array (
      'formit' => '>=4.1.1',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '28f432b5a87041e776a565376ff2be38',
      'native_key' => 'formalicious',
      'filename' => 'modNamespace/a3b270dce309e545d8034295ca84c47e.vehicle',
      'namespace' => 'formalicious',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab1709d940a744372bf1a37b7c26c96a',
      'native_key' => 'formalicious.branding_url',
      'filename' => 'modSystemSetting/da8b0f430f78782d215e6abf496e6a53.vehicle',
      'namespace' => 'formalicious',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '641595a53948a258253b5ddf2b99ce1c',
      'native_key' => 'formalicious.branding_url_help',
      'filename' => 'modSystemSetting/d565c615fdab21c5ed8a60cfd2b04849.vehicle',
      'namespace' => 'formalicious',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05072f08f47fc38c4d1ae5ebbeb9dd5b',
      'native_key' => 'formalicious.saveforms',
      'filename' => 'modSystemSetting/2f1bf539f6278341ad795d1427aaca2f.vehicle',
      'namespace' => 'formalicious',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b13d783da307986c066b20ef3085ab3',
      'native_key' => 'formalicious.saveforms_prefix',
      'filename' => 'modSystemSetting/40e4f820ff4f26fbf91bcbd36ec7c302.vehicle',
      'namespace' => 'formalicious',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc5de19f91fda50403de7f572b61346f',
      'native_key' => 'formalicious.disallowed_hooks',
      'filename' => 'modSystemSetting/7126a88ad7d4962d30390d6e8efc58c2.vehicle',
      'namespace' => 'formalicious',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71cec6a1330088f9db1f6c72760fa55f',
      'native_key' => 'formalicious.preview_css',
      'filename' => 'modSystemSetting/af4cfd72e8b04d04bb3f855d95390749.vehicle',
      'namespace' => 'formalicious',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '944cc2e117142edd7455508b3e6f0124',
      'native_key' => 'formalicious.source',
      'filename' => 'modSystemSetting/b8ecc33b579eb704d8d9dce434553a79.vehicle',
      'namespace' => 'formalicious',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79549f77f3520170318405c7a1a40749',
      'native_key' => 'formalicious.use_editor',
      'filename' => 'modSystemSetting/b4d113cb01c603930979a53e1c47f74c.vehicle',
      'namespace' => 'formalicious',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67bde19a3de8eabff2821c9dd8f40d40',
      'native_key' => 'formalicious.editor_menubar',
      'filename' => 'modSystemSetting/17037a696c9715891b8d6b8cd1050fb0.vehicle',
      'namespace' => 'formalicious',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef533c54f03e04c0b26408cde9d2e4da',
      'native_key' => 'formalicious.editor_plugins',
      'filename' => 'modSystemSetting/4a1f1806ff6ba7fc8deada326bec6a6b.vehicle',
      'namespace' => 'formalicious',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b23f4f22c519c1d2c03d26df42350ab',
      'native_key' => 'formalicious.editor_statusbar',
      'filename' => 'modSystemSetting/8063a316a6a39b05f0247276f01300e9.vehicle',
      'namespace' => 'formalicious',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '377bb3d2367bda7eedfff8e1b6460ae6',
      'native_key' => 'formalicious.editor_toolbar1',
      'filename' => 'modSystemSetting/e12f70106ed954bcc254bfb932b68457.vehicle',
      'namespace' => 'formalicious',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a356cac6c0e1940acaffa33d58aadfe6',
      'native_key' => 'formalicious.editor_toolbar2',
      'filename' => 'modSystemSetting/d1b7318d78b2532e0ef50d26a58e0f7b.vehicle',
      'namespace' => 'formalicious',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47eae809f8114de354b90d6ba1342d0d',
      'native_key' => 'formalicious.editor_toolbar3',
      'filename' => 'modSystemSetting/1144d3383250cd2f0312324b9cb519d7.vehicle',
      'namespace' => 'formalicious',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9efcc08fe514dd644268166461537a5d',
      'native_key' => NULL,
      'filename' => 'modCategory/25350ea0f5bd652d5d4e7aac8ec6c879.vehicle',
      'namespace' => 'formalicious',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8d9adcdaebeec64aa0545f49bc9f246e',
      'native_key' => 'formalicious',
      'filename' => 'modMenu/573341b6880995fb4cfabb8650b44d34.vehicle',
      'namespace' => 'formalicious',
    ),
  ),
);