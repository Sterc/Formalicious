<?php

/**
 * Formalicious
 *
 * Copyright 2019 by Sterc <modx@sterc.nl>
 */

require_once dirname(__DIR__) . '/formaliciousstep.class.php';

class FormaliciousStep_mysql extends FormaliciousStep
{
}
