--------------------
Formalicious
--------------------
Author: Sterc <modx@sterc.nl>
--------------------

Formalicious is the most powerful and easiest MODX form builder, with built-in multi-step forms, 8 field types, validation and the ability to use hooks and other advanced FormIt features.

Important! Since Formalicious 2.0.0 we refactored some snippets and chunks. The snippet RenderForm is replaced with FormaliciousRenderForm.
Please check your snippet and the script properties and check if the chunks/templates of the 'Fieldtypes' are correct.
