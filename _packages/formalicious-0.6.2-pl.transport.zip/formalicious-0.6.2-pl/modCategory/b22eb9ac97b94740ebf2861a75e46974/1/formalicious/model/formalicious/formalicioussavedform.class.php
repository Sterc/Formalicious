<?php
/**
 * @package formalicious
 */
class FormaliciousSavedForm extends xPDOSimpleObject {}
?>