--------------------
Formalicious
--------------------
Version: 0.6
Author: Sterc <modx@sterc.nl>
--------------------
