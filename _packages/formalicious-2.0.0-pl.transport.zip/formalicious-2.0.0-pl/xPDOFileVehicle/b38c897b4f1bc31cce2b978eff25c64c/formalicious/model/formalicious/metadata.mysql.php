<?php

/**
 * Formalicious
 *
 * Copyright 2019 by Sterc <modx@sterc.nl>
 */

$xpdo_meta_map = array(
    'xPDOSimpleObject' => array (
        'FormaliciousCategory',
        'FormaliciousForm',
        'FormaliciousStep',
        'FormaliciousFieldType',
        'FormaliciousField',
        'FormaliciousAnswer'
    )
);