<?php

/**
 * Formalicious
 *
 * Copyright 2019 by Sterc <modx@sterc.nl>
 */

require_once dirname(__DIR__) . '/formaliciouscategory.class.php';

class FormaliciousCategory_mysql extends FormaliciousCategory
{
}
