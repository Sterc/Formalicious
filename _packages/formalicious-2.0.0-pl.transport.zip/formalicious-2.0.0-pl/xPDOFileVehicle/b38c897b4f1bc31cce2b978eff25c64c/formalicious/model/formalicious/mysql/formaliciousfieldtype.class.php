<?php

/**
 * Formalicious
 *
 * Copyright 2019 by Sterc <modx@sterc.nl>
 */

require_once dirname(__DIR__) . '/formaliciousfieldtype.class.php';

class FormaliciousFieldType_mysql extends FormaliciousFieldType
{
}
