<?php
/**
 * Properties Russian Lexicon Entries for Formalicious
 *
 * @package formalicious
 * @subpackage lexicon
 */
$_lang['prop_formalicious.limit_desc'] = 'Лимит вывода количества строк.';
$_lang['prop_formalicious.outputseparator_desc'] = 'Разделитель для вывода строк.';
$_lang['prop_formalicious.sortby_desc'] = 'Поле сортировки.';
$_lang['prop_formalicious.sortdir_desc'] = 'Направление сортировки.';
$_lang['prop_formalicious.tpl_desc'] = 'Чанк оформления каждой строки.';
$_lang['prop_formalicious.toplaceholder_desc'] = 'Если не пусто, то результаты будут выставляться в этот плейсхолдер, вместо вывода на экран.';
