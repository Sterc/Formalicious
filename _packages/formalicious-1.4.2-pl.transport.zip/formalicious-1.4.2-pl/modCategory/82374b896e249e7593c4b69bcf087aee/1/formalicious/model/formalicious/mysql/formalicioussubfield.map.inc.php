<?php
/**
 * @package formalicious
 */
$xpdo_meta_map['FormaliciousSubField']= array (
  'package' => 'formalicious',
  'version' => NULL,
  'table' => 'formalicious_subfields',
  'extends' => 'FormaliciousField',
  'tableMeta' => 
  array (
    'engine' => 'MyISAM',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
