<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'FormaliciousCategory',
    1 => 'FormaliciousForm',
    2 => 'FormaliciousStep',
    3 => 'FormaliciousFieldType',
    4 => 'FormaliciousField',
    5 => 'FormaliciousAnswer',
  ),
  'FormaliciousField' => 
  array (
    0 => 'FormaliciousSubField',
  ),
);