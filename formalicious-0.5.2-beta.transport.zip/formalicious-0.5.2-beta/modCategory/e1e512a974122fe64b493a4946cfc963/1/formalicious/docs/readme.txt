--------------------
Formalicious
--------------------
Version: 1.0.0
Author: Wieger Sloot <modx@sterc.nl>
--------------------
